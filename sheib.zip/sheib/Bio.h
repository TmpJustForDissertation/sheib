#ifndef BIO_H_INCLUDED
#define BIO_H_INCLUDED
#include "PI.h"
#include <vector>
#include <map>
#include <set>
struct Snp{
    std::set<int> * snps=NULL;
    //int * snps=NULL;
    int l=0;
};
class Bio{
public:
    int nGenes;
    Bio(PI * pi);
    ~Bio();
    std::vector<std::string> genes;
    std::map<std::string,int> gene2Index;
    std::vector<int> ** snp2Genes=NULL;
    std::vector<int> ** gene2Snps=NULL;
    std::vector<int> ** associatedGenes=NULL;
    //struct Snp ** snps=NULL;
    void print();
private:
    static const int NAME_SIZE=40;//409600+1;
    PI * pi=NULL;
    bool loadSNP2Genes();
    bool loadAssociatedGenes();
};


#endif // BIO_H_INCLUDED
