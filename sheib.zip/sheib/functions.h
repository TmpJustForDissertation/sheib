#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED
#define STATUS_RUNNING 0
#define STATUS_PAUSING 1
#define STATUS_PAUSED 2
#define STATUS_STOPPING 3
#include <set>
#include "Mem.h"

struct Paras{
    PI * pi=NULL;
    int * status;
};
bool compResult(struct Result * & r1,struct Result * & r2);
int mainReal(PI * pi);
void * control(void * arg);
void print(PI * pi);
void printDocument();
/*
    experiments on simulated datasets.
*/
void expOnDNME100();
void expOnDNME3100();
void expOnDNME1000();
void expOnDME100();
void expOnDME1000();
void forAFile(char * filename,FILE * fo,PI * pi);
void forAModel(char * modelName,PI * p);
int mainExperiment(PI * pi,char models[][40],unsigned int lm);
#endif // FUNCTIONS_H_INCLUDED
